﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectWebApi.Models
{
    public class devManufacturers
    {
        public string id { get; set; }
    }
}