﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectWebApi.Models
{
    public class testManufsAndSystems
    {
        public List<string> testManufs { get; set; }
        public List<string> systems { get; set; }
    }
}