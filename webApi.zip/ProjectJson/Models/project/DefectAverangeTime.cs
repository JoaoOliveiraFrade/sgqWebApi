﻿namespace ProjectWebApi.Models.Project
{
    public class DefectAverangeTime
    {
        public int qtyDefects { get; set; }
        public double qtyHours { get; set; }
        public double averageHours { get; set; }
    }
}