﻿namespace ProjectWebApi.Models.Project
{
    public class DefectReopened
    {
        public int qtyTotal { get; set; }
        public int qtyReopened { get; set; }
        public double percentReopened { get; set; }
        public double percentReference { get; set; }
        public double qtyReference { get; set; }
    }
}