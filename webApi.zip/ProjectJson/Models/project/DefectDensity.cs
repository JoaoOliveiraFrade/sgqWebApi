﻿namespace ProjectWebApi.Models.Project
{
    public class DefectDensity
    {
        public int qtyDefects { get; set; }
        public int qtyCTs { get; set; }
        public double density { get; set; }
    }
}