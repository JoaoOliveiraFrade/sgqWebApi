﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectWebApi.Models.Profile
{
    public class Profile
    {
        public int id { get; set; }
        public string name { get; set; }
    }
}