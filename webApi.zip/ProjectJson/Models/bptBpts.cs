﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectWebApi.Models
{
    public class bptBpts
    {
        public string id { get; set; }
        public string release { get; set; }
        public string classification { get; set; }
        public string project { get; set; }
        public string name { get; set; }
        public string system { get; set; }
        public string status { get; set; }
    }
}