﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjectWebApi.Models
{
    public class bptCadastroStatus
    {
        public string id { get; set; }
        public string release { get; set; }
        public string classification { get; set; }
        public string name { get; set; }
        public string farol { get; set; }
        public string causaraiz { get; set; }
        public string planoacao { get; set; }
        public string informativo { get; set; }
        public string pontoatencao { get; set; }
        public string pontosatencaoindicadores { get; set; }
    }
}