﻿namespace Classes
{
    public enum Bancos
    {
        Sgq, 
        Biti,
        BptHml,
        BptPrd
    };
}
