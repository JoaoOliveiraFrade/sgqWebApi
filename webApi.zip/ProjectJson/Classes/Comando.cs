﻿namespace Classes
{
    public class Comando
    {
        public string Conteudo { get; set; }
    }
}
