select 
	id,
	login,
	name,
	email,
	cpf,
	'' as password
from 
	SGQ_Users