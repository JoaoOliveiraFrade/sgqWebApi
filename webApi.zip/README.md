# apiJson
Disponibilza dados através de Json
